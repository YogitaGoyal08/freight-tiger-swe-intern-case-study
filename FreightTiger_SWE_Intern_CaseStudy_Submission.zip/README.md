# FreightTiger Smart Shipping-Cost Assistant

## What it does
- Reads `shipment_records.csv` and `context_notes.csv`.
- Assigns each shipment to the Monday of its Monday–Sunday week.
- Groups by directed route (`origin-destination`), `route_type`, and week.
- Computes weekly cost per tonne-km as **sum(freight_cost_inr) / sum(quantity_tonnes × distance_km)**. This volume-weighted aggregate avoids giving small shipments the same weight as large shipments.
- Compares each route-week with the mean of up to eight *observed route-weeks strictly before* the current week (no look-ahead). If fewer than eight exist, it uses all prior observed weeks; it does not fill missing weeks.
- Compares with the average cost of all other routes of the same `route_type` in that same week, excluding the route itself.
- Flags a route-week for review when either available baseline comparison is at least **+15%**. The brief does not prescribe a threshold, so 15% is an explicit, configurable heuristic (`THRESHOLD_PCT` in `solution.py`).
- Applies conservative deterministic evidence retrieval to the supplied notes. Only notes with a positive cost-impact claim, matching route, and matching week are allowed to justify a flag. Notes saying there was no impact, normal conditions, or improved roads are not used as justifications. A flagged row without qualifying evidence remains unexplained. `matched_note_id` is populated only when a note qualifies.

## Important interpretation choices
- Route direction is preserved; `A-B` is not merged with `B-A`.
- A route-week with no shipments is absent rather than assigned a fabricated zero cost.
- A missing comparison baseline is reported as `N/A`.
- The provided notes are a small fixed corpus, so the retrieval is rule-based rather than a vector database. This is intentional for exact route/date guardrails and deterministic repeatability. No LLM is called; the assistant never invents a reason when the supplied evidence is insufficient.
- The note window rules are explicit in `note_applies()`: N001 covers the two Monday-start weeks intersecting Feb 24–Mar 8; N002 covers the Jan 20 festival week; N003 is matched to the week starting May 5, when the nationwide diesel change begins. Other notes are non-justifying because they do not claim a positive cost impact applicable to a dataset route/time. This conservative policy avoids using an unrelated or stale note as evidence.

## Run
Requires Python 3.10+ and pandas.

```bash
python solution.py
```

Optional paths:
```bash
python solution.py --data-dir . --output output.csv
```

## Validation / trust checks
Run:
```bash
python evaluate.py
```
The check verifies exact output column order, valid Monday week starts, and that every justified row has a matched note ID. It runs the solution three times and checks the output hashes are identical. The core computation is deterministic and uses no random operations or external APIs.

## Reproducibility
Three repeated runs on the supplied input produced byte-identical CSV output. The evaluation script can reproduce this check.

## LLM token and cost log
- Full input processed: 2,940 shipment rows; 10 context notes; 728 route-week rows produced.
- LLM calls: 0
- Input tokens: 0
- Output tokens: 0
- Estimated LLM cost: $0.00
- Why: the delivered implementation uses deterministic Python calculations and deterministic note matching, not a paid model. Runtime cost is local CPU only. This is transparent and avoids variable model outputs; a future optional LLM could paraphrase retrieved evidence, but must not decide flags or select unmatched notes.
