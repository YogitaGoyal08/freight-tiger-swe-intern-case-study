#!/usr/bin/env python3
"""Small deterministic validation and 3-run reproducibility check."""
from pathlib import Path
import hashlib, subprocess, sys
import pandas as pd

ROOT = Path(__file__).resolve().parent
expected = ["route", "week_of", "cost_per_tonne_km", "vs_own_history",
            "vs_similar_routes", "flagged", "matched_note_id", "reason"]
hashes = []
for i in range(3):
    target = ROOT / f"_repro_run_{i+1}.csv"
    subprocess.run([sys.executable, str(ROOT / "solution.py"),
                    "--data-dir", str(ROOT), "--output", str(target)], check=True)
    raw = target.read_bytes()
    hashes.append(hashlib.sha256(raw).hexdigest())
    df = pd.read_csv(target, keep_default_na=False)
    assert list(df.columns) == expected, "Output schema/order mismatch"
    dates = pd.to_datetime(df["week_of"], errors="raise")
    assert (dates.dt.weekday == 0).all(), "week_of must be a Monday"
    justified = df["flagged"].eq("No (justified)")
    assert df.loc[justified, "matched_note_id"].ne("").all(), "Justified row missing note ID"
    assert df.loc[~justified, "matched_note_id"].eq("").all(), "Unexpected note ID"
    target.unlink()
assert len(set(hashes)) == 1, f"Runs differ: {hashes}"
print("PASS: schema, Monday week starts, note-ID guardrails, and 3 identical runs.")
print("SHA-256:", hashes[0])
