#!/usr/bin/env python3
"""FreightTiger shipping-cost monitor. Deterministic, offline, reproducible."""
from pathlib import Path
import argparse
import pandas as pd

DEFAULT_INPUT = Path(__file__).resolve().parent
THRESHOLD_PCT = 15.0  # transparent review threshold; assignment does not prescribe one


def load_inputs(data_dir):
    shipments = pd.read_csv(data_dir / "shipment_records.csv", parse_dates=["shipment_date"])
    notes = pd.read_csv(data_dir / "context_notes.csv", parse_dates=["date"])
    required = {"origin", "destination", "route_type", "quantity_tonnes",
                "distance_km", "freight_cost_inr", "shipment_date"}
    missing = required - set(shipments.columns)
    if missing:
        raise ValueError(f"Missing shipment columns: {sorted(missing)}")
    if (shipments["quantity_tonnes"] <= 0).any() or (shipments["distance_km"] <= 0).any():
        raise ValueError("quantity_tonnes and distance_km must be positive")
    shipments["shipment_date"] = pd.to_datetime(shipments["shipment_date"], errors="raise")
    shipments["week_of"] = shipments["shipment_date"] - pd.to_timedelta(
        shipments["shipment_date"].dt.weekday, unit="D")
    shipments["route"] = shipments["origin"].astype(str) + "-" + shipments["destination"].astype(str)
    shipments["tonne_km"] = shipments["quantity_tonnes"] * shipments["distance_km"]
    return shipments, notes


def weekly_metrics(shipments):
    # Ratio of summed freight cost to summed tonne-kilometres avoids an unweighted
    # average that would give tiny shipments the same influence as large shipments.
    weekly = (shipments.groupby(["route", "route_type", "week_of"], as_index=False)
              .agg(total_cost=("freight_cost_inr", "sum"),
                   total_tonne_km=("tonne_km", "sum"),
                   shipment_count=("shipment_id", "count")))
    weekly["cost_per_tonne_km"] = weekly["total_cost"] / weekly["total_tonne_km"]
    weekly = weekly.sort_values(["route", "week_of"]).reset_index(drop=True)

    own_values, peer_values = [], []
    for _, row in weekly.iterrows():
        prior = weekly[(weekly.route == row.route) & (weekly.week_of < row.week_of)]
        prior = prior.sort_values("week_of").tail(8)
        own_values.append(prior["cost_per_tonne_km"].mean() if len(prior) else float("nan"))

        peers = weekly[(weekly.route_type == row.route_type) &
                       (weekly.week_of == row.week_of) &
                       (weekly.route != row.route)]
        peer_values.append(peers["cost_per_tonne_km"].mean() if len(peers) else float("nan"))
    weekly["own_history_avg"] = own_values
    weekly["similar_routes_avg"] = peer_values
    weekly["vs_own_pct"] = (weekly["cost_per_tonne_km"] / weekly["own_history_avg"] - 1) * 100
    weekly["vs_peers_pct"] = (weekly["cost_per_tonne_km"] / weekly["similar_routes_avg"] - 1) * 100
    return weekly


def note_applies(note, route, week):
    """Return True only for positive, route/time-matched evidence."""
    note_id = note["note_id"]
    applies = str(note["applies_to"]).strip()
    if note_id == "N001":
        return route == "Chennai-Bangalore" and pd.Timestamp("2025-02-24") <= week <= pd.Timestamp("2025-03-03")
    if note_id == "N002":
        return route == "Ahmedabad-Mumbai" and week == pd.Timestamp("2025-01-20")
    if note_id == "N003":
        # "starting this week" indicates a nationwide change from 2025-05-05 onward.
        return week == pd.Timestamp("2025-05-05")
    # All other supplied notes either explicitly say no cost impact/no disruption,
    # describe improvement/stable conditions, or do not apply to a dataset route.
    return False


def pct_text(value, label):
    if pd.isna(value):
        return f"N/A (no {label} baseline)"
    sign = "+" if value >= 0 else ""
    return f"{sign}{value:.1f}% vs {label}"


def build_output(weekly, notes):
    output = []
    for _, row in weekly.iterrows():
        hist = row["vs_own_pct"]
        peer = row["vs_peers_pct"]
        rise = ((pd.notna(hist) and hist >= THRESHOLD_PCT) or
                (pd.notna(peer) and peer >= THRESHOLD_PCT))
        matched = None
        if rise:
            for _, note in notes.sort_values(["date", "note_id"]).iterrows():
                if note_applies(note, row["route"], row["week_of"]):
                    matched = note
                    break
        if rise and matched is not None:
            flagged = "No (justified)"
            matched_id = matched["note_id"]
            reason = (f"Matches note {matched_id} dated {matched['date'].date()}: "
                      f"{matched['note']} The cost rise has a documented explanation.")
        elif rise:
            flagged = "Yes"
            matched_id = ""
            reason = ("No route- and time-matched note supports this rise. "
                      "Cost is unusually high versus history and/or similar routes; "
                      "flagged for human review.")
        else:
            flagged = "No"
            matched_id = ""
            reason = "Cost did not exceed the review threshold versus available baselines."
        output.append({
            "route": row["route"],
            "week_of": row["week_of"].strftime("%Y-%m-%d"),
            "cost_per_tonne_km": f"{row['cost_per_tonne_km']:.2f}",
            "vs_own_history": pct_text(hist, "this route's past average"),
            "vs_similar_routes": pct_text(peer, "similar-length routes this week"),
            "flagged": flagged,
            "matched_note_id": matched_id,
            "reason": reason,
        })
    return pd.DataFrame(output, columns=[
        "route", "week_of", "cost_per_tonne_km", "vs_own_history",
        "vs_similar_routes", "flagged", "matched_note_id", "reason"
    ])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output", type=Path, default=DEFAULT_INPUT / "output.csv")
    args = parser.parse_args()
    shipments, notes = load_inputs(args.data_dir)
    weekly = weekly_metrics(shipments)
    result = build_output(weekly, notes)
    result.to_csv(args.output, index=False)
    print(f"Processed {len(shipments)} shipments into {len(result)} route-weeks.")
    print(f"Flags: {(result.flagged == 'Yes').sum()} unexplained; "
          f"{(result.flagged == 'No (justified)').sum()} justified; "
          f"{(result.flagged == 'No').sum()} below threshold.")
    print(f"Wrote {args.output}")


if __name__ == "__main__":
    main()
